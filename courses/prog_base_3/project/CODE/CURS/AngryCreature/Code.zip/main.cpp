#include "source/Game.hpp"

int main()
{
 
  RunGame();

  return 0;
}
